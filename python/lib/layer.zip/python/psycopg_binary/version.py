"""
psycopg-c distribution version file.
"""

# Copyright (C) 2020 The Psycopg Team

# Use a versioning scheme as defined in
# https://www.python.org/dev/peps/pep-0440/
__version__ = "3.1.18"

# also change psycopg/psycopg/version.py accordingly.
